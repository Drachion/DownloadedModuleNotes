// James Lynam - X00073019 - Web CA2 - /javascript/album.js


// JavaScript for the Album page
// CRUD operations 
// Parse JSON
// Create album rows
// Display in web page
function displayAlbums(albums) {

  // Use the Array map method to iterate through the array of albums (in json format)
  // Each album will be formated as HTML table rows and added to the array
  // See https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/map
  // Finally the output array is inserted as the content into the <tbody id="albumRows"> element.

  const rows = albums.map(album => {
    // Returns a template string for each album, values are inserted using ${ }
    // <tr> is a table row and <td> a table division represents a column
    // Displaying each column in the album table
    let row = `<tr>
                <td>${album.albumID}</td>
                <td>${album.title}</td>
                <td>${album.genre}</td>
                <td>${album.artistID}</td>`

    // If user logged in then show edit and delete buttons
    // To add - check user role     

    // Show full CRUD functionality if the user's role is admin
    if (userLoggedIn() === true && sessionStorage.role === "admin") {
      row += `<td><button class="btn btn-xs" data-toggle="modal" data-target="#AlbumFormDialog" onclick="prepareAlbumUpdate(${album.albumID})"><span class="oi oi-pencil"></span></button></td>
                   <td><button class="btn btn-xs" onclick="deleteAlbum(${album.albumID})"><span class="oi oi-trash"></span></button></td>`
    }
    // Show limited functionality if the user's role is manager
    else if (userLoggedIn() === true && sessionStorage.role === "manager") {
      row += `<td><button class="btn btn-xs" data-toggle="modal" data-target="#AlbumFormDialog" onclick="prepareAlbumUpdate(${album.albumID})"><span class="oi oi-pencil"></span></button></td>`
    }
    row += '</tr>';

    return row;
  });

  // Set the innerHTML of the albumRows root element = rows
  document.getElementById('albumRows').innerHTML = rows.join('');
} // end function


// load and display artists in a bootstrap list group
function displayArtists(artists) {
  //console.log(artists);
  const items = artists.map(artist => {
    return `<a href="#" class="list-group-item list-group-item-action" onclick="updateAlbumsView(${artist.artistID})">${artist.artistName}</a>`;
  });

  // Add an All artists link at the start
  items.unshift(`<a href="#" class="list-group-item list-group-item-action" onclick="loadAlbums()">Show all</a>`);

  // Set the innerHTML of the albumRows root element = rows
  document.getElementById('artistList').innerHTML = items.join('');
} // end function


// Get all artists and albums then display
async function loadAlbums() {
  try {
    const artists = await getDataAsync(`${BASE_URL}artist`);
    displayArtists(artists);

    const albums = await getDataAsync(`${BASE_URL}album`);
    displayAlbums(albums);

  } // catch and log any errors
  catch (err) {
    console.log(err);
  }
}

// Update album list when artistis selected to show only albums from that artist
async function updateAlbumsView(id) {
  try {
    const albums = await getDataAsync(`${BASE_URL}album/byart/${id}`);
    displayAlbums(albums);

  } // catch and log any errors
  catch (err) {
    console.log(err);
  }
}

// When an album is selected for update/ editing, get it by id and fill out the form
async function prepareAlbumUpdate(id) {

  try {
    // Get album by id
    const album = await getDataAsync(`${BASE_URL}album/${id}`);
    // Fill out the form
    document.getElementById('albumID').value = album.albumID; // uses a hidden field - see the form
    document.getElementById('artistID').value = album.artistID;
    document.getElementById('title').value = album.title;
    document.getElementById('genre').value = album.genre;
  } // catch and log any errors
  catch (err) {
    console.log(err);
  }
}

// Called when form submit button is clicked
async function addOrUpdateAlbum() {

  // url
  let url = `${BASE_URL}album`

  // Get form fields
  const aId = Number(document.getElementById('albumID').value);
  const artId = document.getElementById('artistID').value;
  const aTitle = document.getElementById('title').value;
  const aGenre = document.getElementById('genre').value;

  // build request body
  const reqBody = JSON.stringify({
    artistID: artId,
    title: aTitle,
    genre: aGenre,
  });

  // Try catch 
  try {
    let json = "";
    // determine if this is an insert (POST) or update (PUT)
    // update will include album id
    if (aId > 0) {
      url += `/${aId}`;
      json = await postOrPutDataAsync(url, reqBody, 'PUT');
    }
    else {
      json = await postOrPutDataAsync(url, reqBody, 'POST');
    }
    // Load album
    loadAlbums();
    // catch and log any errors
  } catch (err) {
    console.log(err);
    return err;
  }
}

// Delete album by id using an HTTP DELETE request
async function deleteAlbum(id) {

  if (confirm("Are you sure?")) {
    // url
    const url = `${BASE_URL}album/${id}`;

    // Try catch 
    try {
      const json = await deleteDataAsync(url);
      console.log("response: " + json);

      loadAlbums();

      // catch and log any errors
    } catch (err) {
      console.log(err);
      return err;
    }
  }
}

// Show album button
function showAddAlbumButton() {

  let addAlbumButton = document.getElementById('AddAlbumButton');

  // Hide the add album button for every but admins
  if (userLoggedIn() === true && sessionStorage.role === "admin") {
    addAlbumButton.style.display = 'block';
  }
  else {
    addAlbumButton.style.display = 'none';
  }
}

// show login or logout
showLoginLink();

// Load albums
loadAlbums();

showAddAlbumButton();