// James Lynam - X00073019 - Web CA2 - app.js

const router = require('express').Router();

const jwt = require('jsonwebtoken');
const passport = require('passport');

// Input validation package
// https://www.npmjs.com/package/validator
const validator = require('validator');

// Requiring the database connection
const { sql, dbConnPoolPromise } = require('../database/db.js');

// Define SQL statements here for use in function below
// These are parameterised queries note @named parameters.
// Input parameters are parsed and set before queries are executed

// for json path - Tell MS SQL to return results as JSON 
const SQL_SELECT_ALL = 'SELECT * FROM dbo.Album ORDER BY title ASC for json path;';

// for json path, without_array_wrapper - use for single json result
const SQL_SELECT_BY_ID = 'SELECT * FROM dbo.Album WHERE albumID = @id for json path, without_array_wrapper;';

// for json path, without_array_wrapper - use for single json result
const SQL_SELECT_BY_ARTID = 'SELECT * FROM dbo.Album WHERE artistID = @id ORDER BY title ASC for json path;';

// Second statement (Select...) returns inserted record identified by albumID = SCOPE_IDENTITY()
const SQL_INSERT = 'INSERT INTO dbo.Album (artistID, title, genre) VALUES (@artistID, @title, @genre); SELECT * from dbo.Album WHERE albumID = SCOPE_IDENTITY();';
const SQL_UPDATE = 'UPDATE dbo.Album SET albumID = @albumID, artistID = @artistID, title = @title, genre = @genre WHERE albumID = @id; SELECT * FROM dbo.Album WHERE albumID = @id;';
const SQL_DELETE = 'DELETE FROM dbo.Album WHERE albumID = @id;';


// GET listing of all albums
// Address http://server:port/album
// returns JSON
router.get('/', async (req, res) => {

    // Get a DB connection and execute SQL
    try {
        const pool = await dbConnPoolPromise
        const result = await pool.request()
            // execute query
            .query(SQL_SELECT_ALL);

        // Send HTTP response.
        // JSON data from MS SQL is contained in first element of the recordset.
        res.json(result.recordset[0]);

        // Catch and send errors  
    } catch (err) {
        res.status(500)
        res.send(err.message)
    }
});

// GET a single album by id
// id passed as parameter via url
// Address http://server:port/album/:id
// returns JSON
router.get('/:id', async (req, res) => {

    // read value of id parameter from the request url
    const albumID = req.params.id;

    // Validate input - important as a bad input could crash the server or lead to an attack
    // See link to validator npm package (at top) for doc.
    // If validation fails return an error message
    if (!validator.isNumeric(albumID, { no_symbols: true })) {
        res.json({ "error": "invalid id parameter" });
        return false;
    }

    // If validation passed execute query and return results
    // returns a single album with matching id
    try {
        // Get a DB connection and execute SQL
        const pool = await dbConnPoolPromise
        const result = await pool.request()
            // set name parameter(s) in query
            .input('id', sql.Int, albumID)
            // execute query
            .query(SQL_SELECT_BY_ID);

        // Send response with JSON result    
        res.json(result.recordset[0])

    } catch (err) {
        res.status(500)
        res.send(err.message)
    }
});

// GET albums by artist id
// id passed as parameter via url
// Address http://server:port/album/:id
// returns JSON
router.get('/byart/:id', async (req, res) => {

    // read value of id parameter from the request url
    const artistID = req.params.id;

    // Validate input - important as a bad input could crash the server or lead to an attack
    // See link to validator npm package (at top) for doc.
    // If validation fails return an error message
    if (!validator.isNumeric(artistID, { no_symbols: true })) {
        res.json({ "error": "invalid id parameter" });
        return false;
    }

    // If validation passed execute query and return results
    // returns a single album with matching id
    try {
        // Get a DB connection and execute SQL
        const pool = await dbConnPoolPromise
        const result = await pool.request()
            // set name parameter(s) in query
            .input('id', sql.Int, artistID)
            // execute query
            .query(SQL_SELECT_BY_ARTID);

        // Send response with JSON result    
        res.json(result.recordset[0])

    } catch (err) {
        res.status(500)
        res.send(err.message)
    }
});

// POST - Insert a new album.
// This async function sends a HTTP post request
router.post('/', passport.authenticate('jwt', { session: false }),
    async (req, res) => {

        // Validate - this string, inially empty, will store any errors
        let errors = "";

        // Make sure that artist id is just a number - note that values are read from request body
        const artistID = req.body.artistID;
        if (!validator.isNumeric(artistID, { no_symbols: true })) {
            errors += "invalid artistID ; ";
        }
        // Escape text and potentially bad characters
        const title = validator.escape(req.body.title);
        if (title === "") {
            errors += "invalid title; ";
        }
        const genre = validator.escape(req.body.genre);
        if (genre === "") {
            errors += "invalid genre; ";
        }
        // If no errors, insert
        try {
            // Get a DB connection and execute SQL
            const pool = await dbConnPoolPromise
            const result = await pool.request()
                // set named parameter(s) in query
                .input('artistID', sql.Int, artistID)
                .input('title', sql.NVarChar, title)
                .input('genre', sql.NVarChar, genre)
                // Execute Query
                .query(SQL_INSERT);

            // If successful, return inserted via HTTP   
            res.json(result.recordset[0]);

        } catch (err) {
            res.status(500)
            res.send(err.message)
        }

    });

// PUT update album
// Essentially POST, but we use "'/:id'" and UPDATE instead of INSERT
router.put('/:id', passport.authenticate('jwt', { session: false }),
    async (req, res) => {

        // Validate input values (sent in req.body)
        let errors = "";
        const albumID = req.params.id;
        if (!validator.isNumeric(albumID, { no_symbols: true })) {
            errors += "Invalid Album ID; ";
        }
        const artistID = req.body.artistID;
        if (!validator.isNumeric(artistID, { no_symbols: true })) {
            errors += "Invalid Artist ID; ";
        }
        const title = validator.escape(req.body.title);
        if (title === "") {
            errors += "Invalid Title ";
        }
        const genre = validator.escape(req.body.genre);
        if (genre === "") {
            errors += "Invalid Genre; ";
        }

        // If errors send details in response
        if (errors != "") {
            // return http response with errors if validation failed
            res.json({ "error": errors });
            return false;
        }

        // If no errors
        try {
            // Get a DB connection and execute SQL
            const pool = await dbConnPoolPromise
            const result = await pool.request()
                // set parameters
                .input('id', sql.Int, albumID)
                .input('artistID', sql.Int, aristID)
                .input('title', sql.NVarChar, title)
                .input('genre', sql.NVarChar, genre)
                // run query
                .query(SQL_UPDATE);

            // If successful, return updated album via HTTP    
            res.json(result.recordset[0]);

        } catch (err) {
            res.status(500)
            res.send(err.message)
        }

    });

// DELETE single album.
router.delete('/:id', passport.authenticate('jwt', { session: false }),
    async (req, res) => {

        // Validate
        const albumID = req.params.id;

        // If validation fails return an error message
        if (!validator.isNumeric(albumID, { no_symbols: true })) {
            res.json({ "error": "invalid id parameter" });
            return false;
        }

        // If no errors try delete
        try {
            // Get a DB connection and execute SQL
            const pool = await dbConnPoolPromise
            const result = await pool.request()
                .input('id', sql.Int, albumID)
                .query(SQL_DELETE);


            const rowsAffected = Number(result.rowsAffected);

            let response = { "deletedId": null }

            if (rowsAffected > 0) {
                response = { "deletedId": albumID }
            }

            res.json(response);

        } catch (err) {
            res.status(500)
            res.send(err.message)
        }
    });

module.exports = router;
